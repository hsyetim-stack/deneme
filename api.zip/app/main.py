import os, json, hmac
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

from dotenv import load_dotenv
from redis import Redis
from sqlmodel import select
from sqlalchemy import delete  # <-- ek

from db import init_db, get_session
from models import Signal

load_dotenv()

app = FastAPI(title="saasbot API", version="1.0")

# CORS: hem localhost hem 127.0.0.1 izinli olsun
origins = [
    o.strip() for o in os.environ.get(
        "CORS_ORIGINS",
        "http://localhost:3000,http://127.0.0.1:3000"
    ).split(",")
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

init_db()

REDIS_URL = os.environ.get("REDIS_URL", "redis://redis:6379/0")
redis = Redis.from_url(REDIS_URL, decode_responses=True)

def parse_org_keys(s: str):
    out = {}
    if not s:
        return out
    for pair in s.split(","):
        pair = pair.strip()
        if ":" in pair:
            org, secret = pair.split(":", 1)
            out[org.strip()] = secret.strip()
    return out

ORG_KEYS = parse_org_keys(os.environ.get("ORG_KEYS", "DEMO_ORG:ORG_HMAC_SECRET"))

def constant_time_equals(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode(), b.encode())

@app.get("/health")
def health():
    return {"ok": True, "time": datetime.now(timezone.utc).isoformat()}

@app.get("/api/signals")
def list_signals(limit: int = 50):
    with get_session() as s:
        stmt = select(Signal).order_by(Signal.id.desc()).limit(limit)
        rows = s.exec(stmt).all()
        return [{
            "id": r.id,
            "org_id": r.org_id,
            "event_id": r.event_id,
            "symbol": r.symbol,
            "side": r.side,
            "price": r.price,
            "created_at": r.created_at.isoformat(),
        } for r in rows]

@app.post("/api/webhook/{org}")
def webhook(org: str, payload: dict):
    if org not in ORG_KEYS:
        raise HTTPException(status_code=403, detail="Unknown org")
    if not constant_time_equals(payload.get("secret", ""), ORG_KEYS[org]):
        raise HTTPException(status_code=403, detail="Invalid secret")

    s = Signal(
        org_id=org,
        event_id=str(payload.get("event_id")),
        symbol=str(payload.get("symbol", "")).upper(),
        side=str(payload.get("side", "")).lower(),
        price=float(payload.get("price", 0.0)),
    )
    with get_session() as sess:
        sess.add(s)
        sess.commit()
        sess.refresh(s)

    try:
        redis.publish("signals", json.dumps({
            "id": s.id,
            "org_id": s.org_id,
            "event_id": s.event_id,
            "symbol": s.symbol,
            "side": s.side,
            "price": s.price,
            "created_at": s.created_at.isoformat(),
        }))
    except Exception as e:
        print("[WARN] redis publish failed:", e)

    return {"ok": True, "id": s.id}

# >>> YENİ: TÜM SİNYALLERİ SİL <<<
@app.post("/api/signals/clear")
def clear_signals():
    with get_session() as s:
        s.exec(delete(Signal))
        s.commit()
    try:
        redis.publish("signals", json.dumps({"type": "cleared"}))
    except Exception as e:
        print("[WARN] redis publish failed:", e)
    return {"ok": True}

@app.get("/api/stream/signals")
def stream_signals():
    pubsub = redis.pubsub(ignore_subscribe_messages=True)
    pubsub.subscribe("signals")

    def gen():
        try:
            # İlk bağlanınca ufak bir ping gönderelim ki bağlantı canlı görünsün
            yield "event: ping\ndata: {}\n\n"
            for msg in pubsub.listen():
                if msg and msg.get("type") == "message":
                    yield f"data: {msg['data']}\n\n"
        finally:
            pubsub.close()

    return StreamingResponse(gen(), media_type="text/event-stream")
