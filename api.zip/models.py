
from typing import Optional
from sqlmodel import SQLModel, Field
from datetime import datetime

class Signal(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    org_id: str
    event_id: str
    symbol: str
    side: str
    price: float
    created_at: datetime = Field(default_factory=datetime.utcnow)
