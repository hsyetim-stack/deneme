'use client'
import { useEffect, useState } from 'react'

type Row = {
  id: number
  org_id: string
  event_id: string
  symbol: string
  side: string
  price: number
  created_at: string
}

const API = process.env.NEXT_PUBLIC_API_BASE || 'http://127.0.0.1:8000'

function StatusBadge({ value }: { value: 'optimal'|'degraded'|'down'|string }) {
  const map: Record<string,string> = {
    optimal: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300',
    degraded:'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300',
    down:    'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300',
  }
  const cls = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ' +
              (map[value] ?? 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300')
  return <span className={cls}>{value}</span>
}

function Section({ title, children }: { title:string; children:React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-default bg-card p-5">
      <h3 className="font-semibold mb-3 text-slate-900 dark:text-slate-100">{title}</h3>
      {children}
    </div>
  )
}

export default function DashboardPage() {
  const [rows, setRows] = useState<Row[]>([])
  const [loading, setLoading] = useState(false)

  async function loadSignals() {
    setLoading(true)
    try {
      const res = await fetch(`${API}/api/signals`, { cache: 'no-store' })
      const data = await res.json()
      setRows(data ?? [])
    } finally {
      setLoading(false)
    }
  }

  async function clearSignals() {
    await fetch(`${API}/api/signals/clear`, { method: 'POST' })
    await loadSignals()
  }

  useEffect(() => { loadSignals() }, [])

  return (
    <div className="space-y-6">
      {/* üst şerit */}
      <div className="rounded-2xl border border-default bg-gradient-to-r from-sky-50 to-emerald-50 dark:from-slate-800 dark:to-slate-900 p-6">
        <h1 className="text-2xl font-bold">📊 Dashboard</h1>
        <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
          Hesabının özetini ve sistem durumunu buradan takip edebilirsin.
        </p>
      </div>

      {/* hızlı istatistikler */}
      <div className="grid gap-4 grid-cols-1 md:grid-cols-4">
        <Section title="Aktif Plan"><div className="text-2xl font-bold">Pro</div></Section>
        <Section title="Bugünkü Kullanım"><div className="text-2xl font-bold">API Çağrısı: 132</div></Section>
        <Section title="Son Giriş"><div className="text-2xl font-bold">Bugün, 11:24</div></Section>
        <Section title="Sistem"><StatusBadge value="optimal" /></Section>
      </div>

      {/* durum */}
      <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
        <Section title="Durum">
          <ul className="space-y-2 text-sm">
            <li>
              <span className="text-slate-500 dark:text-slate-400">API:</span>{' '}
              <code className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800">{API}</code>
            </li>
            <li><span className="text-slate-500 dark:text-slate-400">Tema:</span> Light / Dark / Ocean</li>
            <li className="text-slate-500 dark:text-slate-400">Gerçek zamanlı SSE açık.</li>
          </ul>
        </Section>

        {/* tablo üst butonları */}
        <Section title="Sinyaller">
          <div className="flex items-center justify-end gap-2 mb-3">
            <button
              onClick={clearSignals}
              className="inline-flex items-center gap-2 rounded-full bg-emerald-600 px-4 py-2 text-white hover:bg-emerald-700 active:scale-[.98] transition"
              title="Tüm sinyalleri sil"
            >
              🧹 Sinyalleri Sil
            </button>
            <button
              onClick={loadSignals}
              className="inline-flex items-center gap-2 rounded-full bg-slate-200 px-4 py-2 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 transition"
              disabled={loading}
            >
              ↻ {loading ? 'Yükleniyor…' : 'Yenile'}
            </button>
          </div>

          {/* tablo */}
          <div className="overflow-auto rounded-xl border border-default">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/50">
                <tr className="text-left">
                  <th className="p-3">#</th>
                  <th className="p-3">Org</th>
                  <th className="p-3">Event</th>
                  <th className="p-3">Symbol</th>
                  <th className="p-3">Side</th>
                  <th className="p-3">Price</th>
                  <th className="p-3">Created</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="border-t border-default">
                    <td className="p-3">{r.id}</td>
                    <td className="p-3">{r.org_id}</td>
                    <td className="p-3">{r.event_id}</td>
                    <td className="p-3">{r.symbol}</td>
                    <td className="p-3">{r.side}</td>
                    <td className="p-3">{r.price}</td>
                    <td className="p-3">{r.created_at}</td>
                  </tr>
                ))}
                {rows.length === 0 && (
                  <tr><td className="p-4 text-center text-slate-500" colSpan={7}>Kayıt yok</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Section>
      </div>
    </div>
  )
}
