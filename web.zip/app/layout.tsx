// apps/web/app/layout.tsx
import './globals.css'
import { ThemeProvider } from 'next-themes'
import ThemeToggle from '@/components/ThemeToggle'

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="tr" suppressHydrationWarning className="light">
      <body className="min-h-screen bg-background text-foreground">
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem={false}
          storageKey="saasbot-theme"
        >
          {/* Basit bir üst çubuk */}
          <header className="sticky top-0 z-10 border-b bg-white/70 backdrop-blur dark:bg-slate-900/70">
            <div className="mx-auto max-w-6xl px-4 h-12 flex items-center gap-4">
              <a href="/" className="font-semibold">SaaS Premium</a>
              <nav className="text-sm text-slate-600 dark:text-slate-300 flex gap-4">
                <a href="/">Home</a>
                <a href="/dashboard">Dashboard</a>
                <a href="/admin">Admin</a>
              </nav>
              <div className="ml-auto">
                <ThemeToggle />
              </div>
            </div>
          </header>

          <main className="mx-auto max-w-6xl px-4 py-6">
            {children}
          </main>
        </ThemeProvider>
      </body>
    </html>
  )
}
