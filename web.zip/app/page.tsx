
import Navbar from '@/components/Navbar'

export default function Home(){
  return (
    <div>
      <Navbar/>
      <main className="max-w-6xl mx-auto px-4 py-8 space-y-8">
        <div className="card">
          <h1 className="text-2xl font-semibold mb-2">saasbot</h1>
          <p className="text-sm opacity-80">Prod-ready SaaS iskeleti: Next.js + FastAPI + Postgres + Redis + Stripe + Auth.</p>
        </div>
      </main>
    </div>
  )
}
