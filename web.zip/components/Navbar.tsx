'use client'
import Link from 'next/link'
import { useSession, signIn, signOut } from 'next-auth/react'
import ThemeToggle from '@/components/ThemeToggle'

export default function Navbar() {
  const { data: session, status } = useSession()
  const role = (session?.user as any)?.role

  return (
    <nav className="flex gap-4 p-4 bg-card border-b border-default">

      <Link href="/">Home</Link>
      <Link href="/dashboard">Dashboard</Link>
      {(role === 'owner' || role === 'admin') && <Link href="/admin">Admin</Link>}
      <div className="ml-auto flex items-center gap-3">
        {status === 'loading' ? (
          <span>…</span>
        ) : session ? (
          <>
            <span className="mr-2">{session.user?.email} ({role || 'user'})</span>
            <button onClick={() => signOut({ callbackUrl: '/' })}>Sign out</button>
          </>
        ) : (
          <button onClick={() => signIn(undefined, { callbackUrl: '/dashboard' })}>Sign in</button>
        )}
		<ThemeToggle />
      </div>
    </nav>
  )
}
