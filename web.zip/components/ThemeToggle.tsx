// apps/web/(src|app)/components/ThemeToggle.tsx
'use client'
import { useTheme } from 'next-themes'
import { useEffect, useState } from 'react'

export default function ThemeToggle() {
  const { theme, setTheme, resolvedTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])
  if (!mounted) return null

  const themes = [
    { value: 'light', label: '☀️ Light' },
    { value: 'dark',  label: '🌙 Dark'  },
    { value: 'ocean', label: '🌊 Ocean' },
    { value: 'system',label: '🖥️ System' },
  ]

  return (
    <div className="flex items-center gap-2">
      <select
        className="border rounded-xl px-2 py-1 bg-card text-sm"
        value={theme}
        onChange={(e) => setTheme(e.target.value)}
      >
        {themes.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
      </select>
      <span className="text-xs opacity-70">({resolvedTheme})</span>
    </div>
  )
}
