
'use client'
import { useEffect, useRef } from 'react'

export default function TradingViewWidget({symbol="BINANCE:BTCUSDT"}:{ symbol?: string }){
  const ref = useRef<HTMLDivElement>(null)
  useEffect(()=>{
    if(!ref.current) return
    if(ref.current.querySelector('.tradingview-widget-container')) return
    const s = document.createElement('script')
    s.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js'
    s.async = true
    s.innerHTML = JSON.stringify({
      autosize: true, symbol, interval: "15", timezone: "Etc/UTC",
      theme: "light", style: "1", locale: "tr", withdateranges: true,
      allow_symbol_change: true, calendar: false
    })
    const wrap = document.createElement('div')
    wrap.className = 'tradingview-widget-container'
    const inner = document.createElement('div')
    inner.className = 'tradingview-widget-container__widget'
    wrap.appendChild(inner)
    ref.current.appendChild(wrap)
    wrap.appendChild(s)
    return ()=>{ if(ref.current) ref.current.innerHTML='' }
  },[symbol])
  return <div ref={ref} className="w-full h-[520px] rounded-2xl overflow-hidden border" />
}
