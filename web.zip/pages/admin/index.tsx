'use client'
export default function AdminPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Admin Panel</h1>
      <p>Only for owner/admin roles.</p>
    </div>
  )
}
