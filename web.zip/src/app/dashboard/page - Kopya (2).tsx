﻿/* app/dashboard/page.tsx */
import SignalTicker from '@/components/SignalTicker' // alias sorun çıkarsa: import SignalTicker from '../../components/SignalTicker'

const API =
  process.env.NEXT_PUBLIC_API_BASE || 'http://127.0.0.1:8000' // .env.local'dan oku

function StatusBadge({ value }: { value: 'optimal' | 'degraded' | 'down' | string }) {
  const map: Record<string, string> = {
    optimal:
      'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300',
    degraded:
      'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300',
    down: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300',
  }
  const cls =
    'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ' +
    (map[value] ?? 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300')
  return <span className={cls}>{value}</span>
}

function Card({
  title,
  value,
  children,
}: {
  title: string
  value?: React.ReactNode
  children?: React.ReactNode
}) {
  return (
    <div className="rounded-2xl border border-default bg-card shadow-sm p-5 hover:shadow-md transition-shadow">
      <div className="text-xs uppercase tracking-wide text-slate-500 dark:text-slate-400">
        {title}
      </div>
      {value ? (
        <div className="mt-2 text-2xl font-bold text-slate-900 dark:text-slate-100">
          {value}
        </div>
      ) : null}
      {children ? <div className="mt-3 text-slate-700 dark:text-slate-300">{children}</div> : null}
    </div>
  )
}

function Section({
  title,
  children,
}: {
  title: string
  children: React.ReactNode
}) {
  return (
    <div className="rounded-2xl border border-default bg-card p-5">
      <h3 className="font-semibold mb-3 text-slate-900 dark:text-slate-100">
        {title}
      </h3>
      {children}
    </div>
  )
}

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      {/* Üst başlık şeridi */}
      <div className="rounded-2xl border border-default bg-gradient-to-r from-sky-50 to-emerald-50 dark:from-slate-800 dark:to-slate-900 p-6">
        <h1 className="text-2xl font-bold">📊 Dashboard</h1>
        <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
          Hesabının özetini ve sistem durumunu buradan takip edebilirsin.
        </p>
      </div>

      {/* Hızlı istatistikler */}
      <div className="grid gap-4 grid-cols-1 md:grid-cols-4">
        <Card title="Aktif Plan" value={<span>Pro</span>} />
        <Card title="Bugünkü Kullanım" value={<span>API Çağrısı: <b>132</b></span>} />
        <Card title="Son Giriş" value="Bugün, 11:24" />
        <Card title="Sistem">
          <StatusBadge value="optimal" />
        </Card>
      </div>

      {/* Durum & Canlı Sinyal */}
      <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
        <Section title="Durum">
          <ul className="space-y-2 text-sm">
            <li>
              <span className="text-slate-500 dark:text-slate-400">API:</span>{' '}
              <code className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800">
                {API}
              </code>
            </li>
            <li>
              <span className="text-slate-500 dark:text-slate-400">Tema:</span>{' '}
              Light / Dark / Ocean
            </li>
            <li className="text-slate-500 dark:text-slate-400">
              SSE durumu aşağıdaki kutuda canlı görünür.
            </li>
          </ul>
        </Section>

        {/* CANLI sinyal kutusu */}
        <SignalTicker />
      </div>

      {/* Grafik alanı (varsa kendi TradingView bileşenini yerleştir) */}
      <Section title="TradingView • Canlı Grafik">
        <div className="rounded-xl border border-dashed border-default bg-background/50 h-[420px] grid place-items-center">
          <div className="text-sm text-slate-500 dark:text-slate-400">
            Grafik bileşenini burada gösterebilirsin.
          </div>
        </div>
      </Section>
    </div>
  )
}
