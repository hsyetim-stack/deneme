﻿function Card({ title, children }: { title: string, children: React.ReactNode }) {
  return (
    <div className='rounded-2xl border border-slate-200 bg-white shadow-sm p-4'>
      <div className='text-sm text-slate-500'>{title}</div>
      <div className='mt-2 text-slate-900'>{children}</div>
    </div>
  )
}

export default function DashboardPage() {
  return (
    <div>
      <h1 className='text-2xl font-bold mb-4'>📊 Dashboard</h1>
      <div className='grid gap-4 grid-cols-1 md:grid-cols-3'>
        <Card title='Hesap Durumu'>Aktif plan: <b>Pro</b></Card>
        <Card title='Bugünkü Kullanım'>API Çağrısı: <b>132</b></Card>
        <Card title='Son Giriş'>Bugün, 11:24</Card>
      </div>
    </div>
  )
}
