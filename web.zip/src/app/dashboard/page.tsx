﻿'use client'
import Navbar from '@/components/Navbar'
import { useEffect, useState } from 'react'
import TradingViewWidget from '@/components/TradingViewWidget'

// API_BASE değişkenini doğru şekilde tanımla
const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://127.0.0.1:8000'

export default function Dashboard(){
  const [signals, setSignals] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [sseStatus, setSseStatus] = useState<'connecting' | 'connected' | 'error'>('connecting')

  const fetchSignals = async() => {
    try{
      setLoading(true)
      const r = await fetch(`${API_BASE}/api/signals`, { 
        cache: 'no-store',
        headers: {
          'Content-Type': 'application/json',
        }
      })
      if (!r.ok) throw new Error(`HTTP error! status: ${r.status}`)
      const data = await r.json()
      setSignals(data)
    } catch(e) { 
      console.error('Sinyaller alınamadı:', e) 
    } finally { 
      setLoading(false) 
    }
  }

  useEffect(() => {
    fetchSignals()
    
    // SSE bağlantısı
    try {
      const ev = new EventSource(`${API_BASE}/api/stream/signals`)
      
      ev.onopen = () => {
        console.log('SSE bağlantısı açıldı')
        setSseStatus('connected')
      }
      
      ev.onmessage = (e) => {
        try { 
          const newSignal = JSON.parse(e.data)
          setSignals((prev) => [newSignal, ...prev].slice(0, 50)) 
        } catch(error) {
          console.error('SSE mesajı parse edilemedi:', error)
        }
      }
      
      ev.onerror = (error) => {
        console.error('SSE bağlantı hatası:', error)
        setSseStatus('error')
        // 5 saniye sonra yeniden bağlanmayı dene
        setTimeout(() => {
          setSseStatus('connecting')
        }, 5000)
      }

      return () => {
        ev.close()
        console.log('SSE bağlantısı kapatıldı')
      }
    } catch (error) {
      console.error('SSE bağlantısı kurulamadı:', error)
      setSseStatus('error')
    }
  }, [])

  return (
    <div>
      <Navbar/>
      <main className="max-w-6xl mx-auto px-4 py-8 space-y-8">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="card">
            <h2 className="text-lg font-semibold mb-2">Durum</h2>
            <ul className="text-sm space-y-1">
              <li>API: <code>{API_BASE}</code></li>
              <li>Tema: Light/Dark/Ocean</li>
              <li>Gerçek zamanlı SSE: 
                <span className={`ml-1 ${
                  sseStatus === 'connected' ? 'text-green-600' : 
                  sseStatus === 'connecting' ? 'text-yellow-600' : 'text-red-600'
                }`}>
                  {sseStatus === 'connected' ? 'Bağlı' : 
                   sseStatus === 'connecting' ? 'Bağlanıyor...' : 'Bağlantı Hatası'}
                </span>
              </li>
            </ul>
          </div>
          <div className="card">
            <h2 className="text-lg font-semibold mb-2">İpuçları</h2>
            <ul className="list-disc pl-5 text-sm space-y-1">
              <li>TradingView görsel; gerçek sinyaller bottan gelir</li>
              <li>Break-Even / Trailing / TP çoklu seviye yakında</li>
              <li>Admin ve RBAC sırada</li>
            </ul>
          </div>
        </div>

        <div className="card">
          <h2 className="text-lg font-semibold mb-3">TradingView • Canlı Grafik</h2>
          <TradingViewWidget symbol="BINANCE:BTCUSDT"/>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">📈 Sinyaller</h2>
            <button 
              onClick={fetchSignals} 
              className="btn btn-primary"
              disabled={loading}
            >
              {loading ? '...' : '↻ Yenile'}
            </button>
          </div>
          
          {loading ? (
            <p className="text-center py-4">Yükleniyor...</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left border-b border-default">
                    <th className="p-2">#</th>
                    <th className="p-2">Org</th>
                    <th className="p-2">Event</th>
                    <th className="p-2">Symbol</th>
                    <th className="p-2">Side</th>
                    <th className="p-2">Price</th>
                    <th className="p-2">Created</th>
                  </tr>
                </thead>
                <tbody>
                  {signals.map((s: any) => (
                    <tr key={s.id} className="border-b border-default last:border-0">
                      <td className="p-2">{s.id}</td>
                      <td className="p-2">{s.org_id}</td>
                      <td className="p-2">{s.event_id}</td>
                      <td className="p-2">{s.symbol}</td>
                      <td className="p-2">{s.side}</td>
                      <td className="p-2">{s.price}</td>
                      <td className="p-2">
                        {new Date(s.created_at).toLocaleString('tr-TR')}
                      </td>
                    </tr>
                  ))}
                  {signals.length === 0 && !loading && (
                    <tr>
                      <td colSpan={7} className="p-4 text-center text-muted">
                        Henüz sinyal yok.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}