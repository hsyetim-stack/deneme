﻿import './globals.css'
import Providers from '@/app/providers'
import Navbar from '@/components/Navbar'

export const metadata = { title: 'SaaS Premium' }

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="tr" suppressHydrationWarning>
      <body className="min-h-screen bg-background text-foreground">
        <Providers>
          <Navbar />
          <main className="mx-auto max-w-6xl p-6">{children}</main>
        </Providers>
      </body>
    </html>
  )
}
