'use client'
import { useEffect, useState } from 'react'

const API = process.env.NEXT_PUBLIC_API_BASE || 'http://127.0.0.1:8000'

export default function SignalTicker() {
  const [last, setLast] = useState<string>('–')
  const [ok, setOk] = useState<boolean>(false)

  useEffect(() => {
    const es = new EventSource(`${API}/api/stream/signals`)
    es.onopen = () => setOk(true)
    es.onerror = () => setOk(false)
    es.onmessage = (e) => {
      try {
        const d = JSON.parse(e.data)
        if (d?.type === 'clear') {
          setLast('Temizlendi')
        } else {
          setLast(`${d.org_id} • ${d.symbol} • ${d.side} • ${d.price}`)
        }
      } catch {
        setLast(e.data)
      }
    }
    return () => es.close()
  }, [])

  return (
    <div className="rounded-2xl border border-default bg-card p-5">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Canlı Sinyal</h3>
        <span className={`text-xs ${ok?'text-green-600':'text-amber-600'}`}>
          {ok ? 'SSE: Açık' : 'SSE: Kapalı'}
        </span>
      </div>
      <div className="mt-2 text-sm text-slate-700 dark:text-slate-300">
        {last}
      </div>
    </div>
  )
}
